/**
 * @file
 */

#ifndef SUMMARY_STAT_H
#define SUMMARY_STAT_H

/**
 * @fn summary_statistic
 */

int summary_statistic (const char *, const int, const int, const int, const int *, 
                       const int *);

#endif /* SUMMARY_STAT_H */