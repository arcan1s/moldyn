/**
 * @file
 */

#ifndef MESSAGES_H
#define MESSAGES_H

/**
 * @fn message
 */

int message (const int, const int, const char *, FILE *);

#endif /* MESSAGES_H */