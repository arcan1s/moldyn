/**
 * @file
 */

#ifndef RADF_PROC_H
#define RADF_PROC_H

/**
 * @fn print_result
 */

int print_result (const char *, const int, const int, const int, const int, const double, 
                  const double, const double, const double, const double, const double, 
                  const float *, const int *);

#endif /* RADF_PROC_H */