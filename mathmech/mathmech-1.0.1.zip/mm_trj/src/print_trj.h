/**
 * @file
 */

#ifndef PRINT_TRJ_H
#define PRINT_TRJ_H

/**
 * @fn printing_trj
 */

int printing_trj (const char *, const int, const int, const int *, const int *, 
                  const char *, const int *, const float *);

#endif /* PRINT_TRJ_H */