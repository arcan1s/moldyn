/**
 * @file
 */

#ifndef ATOM_TYPES_H
#define ATOM_TYPES_H

/**
 * @fn reading_atoms
 */

int reading_atoms (const char *, int *, int *, int *, char *, int *, const int);

#endif /* ATOM_TYPES_H */