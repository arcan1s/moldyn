/**
 * @file
 */

#ifndef STAT_SORT_H
#define STAT_SORT_H

/**
 * @fn proc_matrix
 */

int proc_matrix (const int, const int *, int *, int *, int *, int *);

#endif /* STAT_SORT_H */