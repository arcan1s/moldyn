/**
 * @file
 */

#ifndef SELECT_MOL_H
#define SELECT_MOL_H

/**
 * @fn select_molecule
 */

int select_molecule (const float *, const int, int *);

#endif /* SELECT_MOL_H */