/**
 * @file
 */

#ifndef READ_AGL_H
#define READ_AGL_H

/**
 * @fn reading_agl
 */

int reading_agl (const char *, int *, char *, int *);

#endif /* READ_AGL_H */