/**
 * @file
 */

#ifndef READ_PUMA_H
#define READ_PUMA_H

/**
 * @fn rw_puma
 */

int rw_puma (const char *, const int, const char *, const int, const int *, 
             const int *, const char *, const int *, float *);

#endif /* READ_PUMA_H */