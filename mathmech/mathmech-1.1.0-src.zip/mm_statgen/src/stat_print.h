/**
 * @file
 */

#ifndef STAT_PRINT_H
#define STAT_PRINT_H

/**
 * @fn printing_agl
 */

int printing_agl (const char *, const char *, const int *, const int, const int *, 
                  const int *, const int *, const int *, const int,int *);

#endif /* STAT_PRINT_H */