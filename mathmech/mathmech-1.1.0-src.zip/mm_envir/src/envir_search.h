/**
 * @file
 */

#ifndef ENVIR_SEARCH_H
#define ENVIR_SEARCH_H

/**
 * @fn search_envir
 */

int search_envir (const int, const int, const float *, const double, int *, int *);

#endif /* ENVIR_SEARCH_H */