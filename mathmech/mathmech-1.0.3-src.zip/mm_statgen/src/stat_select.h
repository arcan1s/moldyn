/**
 * @file
 */

#ifndef STAT_SELECT_H
#define STAT_SELECT_H

/**
 * @fn create_matrix
 */

int create_matrix (const int, const int, const int *, const int *, const float *, 
                   const int, const float *, int *);

#endif /* STAT_SELECT_H */