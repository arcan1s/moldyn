/**
 * @file
 */

#ifndef SET_CENTER_H
#define SET_CENTER_H

/**
 * @fn set_center
 */

int set_center (const int, const int, const int *, const float *, float *);

#endif /* SET_CENTER_H */